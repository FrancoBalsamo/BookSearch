package com.dafran.booksearch.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.dafran.booksearch.Adaptador.ParseAdapter;
import com.dafran.booksearch.Clases.Conexion;
import com.dafran.booksearch.Clases.TrantorItems;
import com.dafran.booksearch.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class TMOnline extends AppCompatActivity {
    Button buscar;
    EditText textoBusqueda;
    AdView adView;

    private RecyclerView recyclerView;
    private ParseAdapter adapter;
    private ArrayList<TrantorItems> trantorItems = new ArrayList<>();
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t_m_online);
    }

    @Override
    protected void onResume() {
        super.onResume();

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ParseAdapter(trantorItems, this);
        recyclerView.setAdapter(adapter);

        textoBusqueda = (EditText)findViewById(R.id.etBuscar);

        String texto = textoBusqueda.getText().toString();
        buscar = (Button)findViewById(R.id.btnBusqueda);

        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFrom(getApplicationContext(), textoBusqueda);

                if(new Conexion().isOnline(TMOnline.this)){
                    if(TextUtils.isEmpty(textoBusqueda.getText())){
                        Toast.makeText(TMOnline.this, "Debe ingresar el nombre del libro.", Toast.LENGTH_LONG).show();
                        textoBusqueda.setFocusable(true);
                    }else{
                        Content content = new Content();
                        content.execute();
                    }
                }else {
                    Toast.makeText(TMOnline.this, "Se requiere conexión a internet.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private class Content extends AsyncTask<Void,Void, ArrayList<TrantorItems>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            progressBar.startAnimation(AnimationUtils.loadAnimation(TMOnline.this, android.R.anim.fade_in));
        }

        @Override
        protected void onPostExecute(ArrayList<TrantorItems> items) {
            super.onPostExecute(items);
            progressBar.setVisibility(View.GONE);
            progressBar.startAnimation(AnimationUtils.loadAnimation(TMOnline.this, android.R.anim.fade_out));
            //Actualizar información
            adapter.updateData(items);
            adapter.notifyDataSetChanged();
        }

        @Override
        protected ArrayList<TrantorItems> doInBackground(Void... voids) {
            String texto = textoBusqueda.getText().toString();
            String arreglo = texto.replace(' ', '+');
            String url = "https://lectortmo.com/library?_page=1&title=" + arreglo;
            try {
                Document doc = Jsoup.connect(url).get();

                Elements data = doc.select("div.row");
                int size = data.size();
                Log.d("doc", "doc: "+doc);
                Log.d("data", "data: "+data);
                Log.d("size", ""+size);
                for (int i = 0; i < size; i++) {
                    String title = data.select("div.thumbnail-title")
                            .select("h4")
                            .eq(i)
                            .attr("tittle"); //nombre del manhwa
                    String imgUrl = data.select("style")
                            .select("background-image")
                            .eq(i)
                            .attr("url"); //imagen del manga
                    String detailUrl = data.select("div.row")
                            .select("a")
                            .eq(i)
                            .attr("href");
                    String urlManga = data.select("div.row")
                            .select("a")
                            .eq(i)
                            .attr("href");

                    //trantorItems.add(new TrantorItems(imgUrl, title, detailUrl, urlManga));
                }
            }  catch (IOException e) {
                e.printStackTrace();
            }
            return trantorItems;
        }
    }

    public static void hideKeyboardFrom(Context context, View view) {
        InputMethodManager imm = (InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean isNullorEmpty(String s ) {
        return s == null || s.trim().isEmpty();
    }

    private void bannerBookSearh(){
        MobileAds.initialize(TMOnline.this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) { }
        });
        adView = (AdView)findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TMOnline.this.finish();
    }
}