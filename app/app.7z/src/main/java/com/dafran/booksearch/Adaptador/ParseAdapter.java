package com.dafran.booksearch.Adaptador;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.dafran.booksearch.Clases.TrantorItems;
import com.dafran.booksearch.R;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ParseAdapter extends RecyclerView.Adapter<ParseAdapter.ViewHolder> {

    private ArrayList<TrantorItems> trantorItems;
    private Context context;

    public ParseAdapter(ArrayList<TrantorItems> trantorItems, Context context) {
        this.trantorItems = trantorItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ParseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.vista_recycler, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ParseAdapter.ViewHolder holder, int position) {
        TrantorItems trantorItems = this.trantorItems.get(position);
        holder.textView.setText(trantorItems.getTitle());
        holder.idioma.setText(trantorItems.getIdioma());
        Picasso.get().load(trantorItems.getImgUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return trantorItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView textView, idioma;

        public ViewHolder(@NonNull View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
            textView = view.findViewById(R.id.textView);
            idioma = view.findViewById(R.id.tvIdioma);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int itemPosition = getAdapterPosition();
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(trantorItems.get(itemPosition).getUrlDescarga())));
        }
    }

    public void setFilter(ArrayList<TrantorItems> newList) {
        trantorItems = new ArrayList<>();
        trantorItems.addAll(newList);
        notifyDataSetChanged();
    }

    public void updateData(ArrayList<TrantorItems> items) {
        this.trantorItems = items;
    }
}